package br.com.projeto;

public class Aluno {
	
	private String nome;
	private String matrAluno;
	private String senha;
	private String curso;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMatrAluno() {
		return matrAluno;
	}
	public void setMatrAluno(String matrAluno) {
		this.matrAluno = matrAluno;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	

}
