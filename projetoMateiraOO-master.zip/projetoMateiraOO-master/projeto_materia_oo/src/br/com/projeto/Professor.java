package br.com.projeto;

public class Professor {
	
	private String nome;
	private String matrFunc;
	private String senha;
	private String disciplina;
	private String email;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMatrFunc() {
		return matrFunc;
	}
	public void setMatrFunc(String matrFunc) {
		this.matrFunc = matrFunc;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
