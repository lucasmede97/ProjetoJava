package br.com.projeto;

public class Coordenador {
	
	private String nome;
	private String matrFunc;
	private String senha;
	private String email;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMatrFunc() {
		return matrFunc;
	}
	public void setMatrFunc(String matrFunc) {
		this.matrFunc = matrFunc;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
}
